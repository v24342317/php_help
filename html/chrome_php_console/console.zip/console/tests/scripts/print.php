<?php

echo $string;
