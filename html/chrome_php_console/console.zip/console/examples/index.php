<?php
  

$array = array(
    'test' => 1,
    'test2' => 1,
    'key' => array(
       "asd"=>"sdf",
	   "sdf"=>98
    ), 
);
__debugs($array,"试试");


function __debugs($data, $tittle){
	require_once(__DIR__ . '/../src/PhpConsole/__autoload.php');
  
$password = 'test';
$connector = PhpConsole\Connector::getInstance();
$connector->setPassword($password);
  
// Call debug from PhpConsole\Handler
$handler = PhpConsole\Handler::getInstance();
$handler->start();
$handler->debug($data, $tittle);
}